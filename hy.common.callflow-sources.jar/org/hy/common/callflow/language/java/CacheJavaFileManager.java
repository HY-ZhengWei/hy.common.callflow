package org.hy.common.callflow.language.java;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;
import java.util.Set;

import javax.tools.FileObject;
import javax.tools.ForwardingJavaFileManager;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileManager;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import javax.tools.JavaCompiler.CompilationTask;
import javax.tools.JavaFileObject.Kind;

import org.hy.common.Help;





/**
 * 内存编译源码的文件管理者
 *
 * @author      ZhengWei(HY)
 * @createDate  2025-12-08
 * @version     v1.0
 */
public class CacheJavaFileManager extends ForwardingJavaFileManager<JavaFileManager> 
{
    
    /** 缓存所有编译码对象。Map.key为类名称 */
    private static final Map<String ,CacheJavaFileObject> $ClassJavaFileObjects = new HashMap<String ,CacheJavaFileObject>();
    
    /** 缓存所有类加载器。Map.key为类名称 */
    private static final Map<String ,CacheClassLoader>    $ClassLoaders         = new HashMap<String ,CacheClassLoader>();
    
    /** 管理者的采用单例模式 */
    private static CacheJavaFileManager                   $CacheJavaFileManager = null;
    
    /** 编译器 */
    private static JavaCompiler                           $JavaCompiler;
    
    
    
    /**
     * 获取实例
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-08
     * @version     v1.0
     *
     * @return
     */
    public static CacheJavaFileManager getInstanceof()
    {
        synchronized ( $ClassJavaFileObjects )
        {
            if ( $CacheJavaFileManager == null )
            {
                // 1. 获取Java编译器实例
                // JavaCompiler是 JDK 内置的编译器 API，用于编译 Java 源码（需使用 JDK 运行，JRE 无此 API）
                $JavaCompiler = ToolProvider.getSystemJavaCompiler();
                if ( $JavaCompiler == null ) 
                {
                    return null;
                }
                
                // 2. 自定义文件管理器（管理内存中的源码/字节码）
                StandardJavaFileManager v_StandardJavaManager = $JavaCompiler.getStandardFileManager(null, null, StandardCharsets.UTF_8);
                $CacheJavaFileManager = new CacheJavaFileManager(v_StandardJavaManager);
            }
        }
        
        return $CacheJavaFileManager;
    }
    
    
    
    /**
     * 构造器
     *
     * @author      ZhengWei(HY)
     * @createDate  2025-12-08
     * @version     v1.0
     *
     * @param i_JavaFileManager  JDK的Java文件管理器
     */
    private CacheJavaFileManager(JavaFileManager i_JavaFileManager)
    {
        super(i_JavaFileManager);
    }
    
    
    
    /**
     * 编译源码
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-08
     * @version     v1.0
     *
     * @param i_ClassName   类名称
     * @param i_SourceCode  源码
     * @return
     */
    public boolean compiler(String i_ClassName ,String i_SourceCode)
    {
        if ( $CacheJavaFileManager == null )
        {
            return false;
        }
        
        if ( Help.isNull(i_ClassName) || Help.isNull(i_SourceCode) )
        {
            return false;
        }
        
        List<String> v_Options = new ArrayList<>();
        v_Options.add("-encoding");
        v_Options.add("UTF-8");
        v_Options.add("-proc:none");                     // 禁用注解处理器 → 解决冲突错误
        v_Options.add("--release=17");
        // v_Options.add("-Djdk.module.path=");
        // v_Options.add("-Xlint:-module");
        // v_Options.add("--add-modules=ALL-SYSTEM");
        // v_Options.add("-classpath");
        // v_Options.add(CacheClassLoader.buildClassPath());
                
        // 3. 创建编译任务（可选：如编码、类路径）
        //   参数01：输出流（null使用系统默认）
        //   参数02：文件管理器（自定义内存文件管理器）
        //   参数03：诊断监听器
        //   参数04：编译参数
        //   参数05：注解处理器
        //   参数06：待编译的源码
        CompilationTask v_CompilationTask = $JavaCompiler.getTask(null                                                                  
                                                              ,$CacheJavaFileManager
                                                              ,null
                                                              ,v_Options           // 关闭调试信息，减小字节码体积
                                                              ,null
                                                              ,$CacheJavaFileManager.getJavaFileObjects(i_ClassName ,i_SourceCode));
        
        // 4. 执行编译
        boolean v_CompileSuccess = v_CompilationTask.call();
        return v_CompileSuccess;
    }
    
    
    
    /**
     * 类加载
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-08
     * @version     v1.0
     *
     * @param i_ClassName
     * @return
     * @throws ClassNotFoundException
     */
    public Class<?> loadClass(String i_ClassName) throws ClassNotFoundException
    {
        if ( $CacheJavaFileManager == null )
        {
            return null;
        }
        
        if ( Help.isNull(i_ClassName) )
        {
            return null;
        }
        
        CacheClassLoader v_ClassLoader = null;
        synchronized ($ClassLoaders)
        {
            v_ClassLoader = $ClassLoaders.get(i_ClassName);
            if ( v_ClassLoader != null )
            {
                $ClassLoaders.remove(i_ClassName);
                v_ClassLoader = null;
            }
            
            v_ClassLoader = new CacheClassLoader(i_ClassName);
            $ClassLoaders.put(i_ClassName ,v_ClassLoader);
            
            CacheClassLoader.getInstanceof();
        }
        
        // 5. 获取编译后的字节码，通过自定义类加载器加载
        return v_ClassLoader.loadClass();
    }
    
    
    
    /**
     * 获取某个内存编译源码对象
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-08
     * @version     v1.0
     *
     * @param i_ClassName  类名称
     * @return
     */
    public CacheJavaFileObject get(String i_ClassName)
    {
        if ( $CacheJavaFileManager == null )
        {
            return null;
        }
        else
        {
            return $ClassJavaFileObjects.get(i_ClassName);
        }
    }
    
    
    
    /**
     * 获取待编译的源码文件对象
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-08
     * @version     v1.0
     *
     * @param i_ClassName   类名称
     * @param i_SourceCode  源码
     * @return
     */
    public Iterable<JavaFileObject> getJavaFileObjects(String i_ClassName ,String i_SourceCode) 
    {
        return Collections.singletonList(new CacheJavaFileObject(i_ClassName, i_SourceCode));
    }

    
    
    /**
     * 为编译输出创建内存文件对象
     *
     * @author      ZhengWei(HY)
     * @createDate  2025-12-08
     * @version     v1.0
     *
     * @param i_Location
     * @param i_ClassName   类名称
     * @param i_Kind        种类（源码、编译后的字节码）。实现值只为编译后的字节码
     * @param i_Sibling     编译字节码对应的源码。即：CacheJavaFileObject类
     * @return
     * @throws IOException
     *
     * @see javax.tools.ForwardingJavaFileManager#getJavaFileForOutput(javax.tools.JavaFileManager.Location, java.lang.String, javax.tools.JavaFileObject.Kind, javax.tools.FileObject)
     */
    @Override
    public JavaFileObject getJavaFileForOutput(Location i_Location ,String i_ClassName ,Kind i_Kind ,FileObject i_Sibling) throws IOException
    {
        if ( i_Kind == Kind.CLASS) 
        {
            synchronized ($ClassJavaFileObjects)
            {
                String v_SourceCode = null;
                if ( i_Sibling instanceof CacheJavaFileObject )
                {
                    v_SourceCode = ((CacheJavaFileObject) i_Sibling).getSourceCode();
                }
                
                CacheJavaFileObject v_JavaFileObject = new CacheJavaFileObject(i_ClassName ,v_SourceCode ,i_Kind);
                $ClassJavaFileObjects.put(i_ClassName ,v_JavaFileObject);
                
                return v_JavaFileObject;
            }
        }
        else
        {
            return super.getJavaFileForOutput(i_Location, i_ClassName, i_Kind, i_Sibling);
        }
    }
    
    
    
    /**
     * 编译器查找类（如B找A）时，从内存MAP中读取字节码
     *
     * @author      ZhengWei(HY)
     * @createDate  2025-12-09
     * @version     v1.0
     *
     * @param i_Location
     * @param i_ClassName
     * @param i_Kind
     * @return
     * @throws IOException
     *
     * @see javax.tools.ForwardingJavaFileManager#getJavaFileForInput(javax.tools.JavaFileManager.Location, java.lang.String, javax.tools.JavaFileObject.Kind)
     */
    @Override
    public JavaFileObject getJavaFileForInput(Location i_Location, String i_ClassName, Kind i_Kind) throws IOException 
    {
        if ( i_Kind == Kind.CLASS )
        {
            // 优先从内存MAP找已编译的类
            CacheJavaFileObject v_JavaFileObject = $ClassJavaFileObjects.get(i_ClassName);
            if ( v_JavaFileObject != null )
            {
                return v_JavaFileObject;
            }
        }
        return super.getJavaFileForInput(i_Location ,i_ClassName ,i_Kind);
    }
    
    
    
    /**
     * 编译器扫描类路径时，暴露内存中的类
     *
     * @author      ZhengWei(HY)
     * @createDate  2025-12-09
     * @version     v1.0
     *
     * @param i_Location
     * @param i_PackageName
     * @param i_Kinds
     * @param i_Recurse
     * @return
     * @throws IOException
     *
     * @see javax.tools.ForwardingJavaFileManager#list(javax.tools.JavaFileManager.Location, java.lang.String, java.util.Set, boolean)
     */
    @Override
    public Iterable<JavaFileObject> list(Location i_Location, String i_PackageName, Set<Kind> i_Kinds, boolean i_Recurse) throws IOException 
    {
        Iterable<JavaFileObject> v_StandardFiles = super.list(i_Location, i_PackageName, i_Kinds, i_Recurse);
        List<JavaFileObject>     v_AllFiles      = new ArrayList<>();
        
        v_StandardFiles.forEach(v_AllFiles::add);

        // 如果是查找CLASS类型，补充内存中的类
        if ( i_Kinds.contains(Kind.CLASS) )
        {
            String v_PackagePrefix = i_PackageName.isEmpty() ? "" : i_PackageName + ".";
            // 遍历内存MAP，匹配包名的类加入列表
            for (String v_ClassName : $ClassJavaFileObjects.keySet())
            {
                if ( v_ClassName.startsWith(v_PackagePrefix) )
                {
                    String v_RelativeClassName = v_ClassName.substring(v_PackagePrefix.length());
                    if ( !i_Recurse && v_RelativeClassName.contains(".") )
                    {
                        continue; // 非递归时跳过子包
                    }
                    v_AllFiles.add(getJavaFileForInput(i_Location ,v_ClassName ,Kind.CLASS));
                }
            }
        }
        return v_AllFiles;
    }
    
    
    
    /**
     * 重写inferBinaryName，手动返回二进制名
     *
     * @author      ZhengWei(HY)
     * @createDate  2025-12-09
     * @version     v1.0
     *
     * @param i_Location
     * @param i_File
     * @return
     *
     * @see javax.tools.ForwardingJavaFileManager#inferBinaryName(javax.tools.JavaFileManager.Location, javax.tools.JavaFileObject)
     */
    @Override
    public String inferBinaryName(Location i_Location ,JavaFileObject i_File)
    {
        if ( i_File instanceof CacheJavaFileObject )
        {
            return ((CacheJavaFileObject) i_File).getClassName();
        }
        
        return super.inferBinaryName(i_Location ,i_File);
    }
    
    
    
    @Override
    public ClassLoader getClassLoader(Location location)
    {
        synchronized (this)
        {
            // 关键：强制返回 SpringBoot + Tomcat 的类加载器
            if ( CacheClassLoader.$SystemClassLoader == null )
            {
                CacheClassLoader.$SystemClassLoader = Thread.currentThread().getContextClassLoader();
            }
            return CacheClassLoader.$SystemClassLoader;
        }
    }
    
    
    
    @Override
    public boolean hasLocation(Location i_Location) 
    {
        boolean v_HasLocation = super.hasLocation(i_Location);
        if ( !v_HasLocation )
        {
            if ( "ANNOTATION_PROCESSOR_MODULE_PATH".equals(i_Location.getName()) 
              || "ANNOTATION_PROCESSOR_PATH".equals(i_Location.getName())
              || "SOURCE_PATH".equals(i_Location.getName()) )
            {
                return false;
            }
            if ( "PATCH_MODULE_PATH".equals(i_Location.getName()) 
              || "MODULE_SOURCE_PATH".equals(i_Location.getName())
              || "SOURCE_OUTPUT".equals(i_Location.getName())
              || "CLASS_OUTPUT".equals(i_Location.getName()) )
           {
                return true;
           }
            System.out.println(i_Location.getName() + " = " + i_Location.toString());
        }
        
        return v_HasLocation;
    }
    
    
    
    @Override
    public <S> ServiceLoader<S> getServiceLoader(Location location, Class<S> service) throws IOException 
    {
        // 直接返回空，永不执行父类代码
        return ServiceLoader.load(service, getClassLoader(location));
    }
    
    
    
    /**
     * 获取类的字节码
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-08
     * @version     v1.0
     *
     * @param i_ClassName  类名称
     * @return
     */
    public byte [] getClassBytes(String i_ClassName)
    {
        return $ClassJavaFileObjects.get(i_ClassName).getByteCode();
    }
    
}
