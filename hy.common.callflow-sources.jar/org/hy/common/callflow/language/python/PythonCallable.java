package org.hy.common.callflow.language.python;

import java.util.Map;
import java.util.concurrent.Callable;

import org.hy.common.callflow.execute.ExecuteResult;
import org.hy.common.callflow.language.PythonConfig;

import jep.SubInterpreter;

public class PythonCallable implements Callable<ExecuteResult>
{
    
    private PythonConfig        pyConfig;
    
    private ExecuteResult       result;
    
    private Map<String ,Object> context;
    
    
    
    public PythonCallable(PythonConfig i_PYConfig ,ExecuteResult i_Result ,Map<String ,Object> io_Context)
    {
        this.pyConfig = i_PYConfig;
        this.result   = i_Result;
        this.context  = io_Context;
    }
    

    @Override
    public ExecuteResult call() throws Exception
    {
        try (SubInterpreter v_Jep = new SubInterpreter())
        {
            return this.pyConfig.executeCallable(this.result ,this.context ,v_Jep);
        }
    }
    
}
