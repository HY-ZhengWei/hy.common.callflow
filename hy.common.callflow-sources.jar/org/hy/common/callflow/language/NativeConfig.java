package org.hy.common.callflow.language;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.hy.common.Date;
import org.hy.common.Help;
import org.hy.common.Return;
import org.hy.common.StringHelp;
import org.hy.common.callflow.CallFlow;
import org.hy.common.callflow.common.ValueHelp;
import org.hy.common.callflow.enums.ElementType;
import org.hy.common.callflow.enums.ExportType;
import org.hy.common.callflow.enums.RouteType;
import org.hy.common.callflow.execute.ExecuteElement;
import org.hy.common.callflow.execute.ExecuteResult;
import org.hy.common.callflow.file.IToXml;
import org.hy.common.callflow.node.NodeConfig;
import org.hy.common.callflow.node.NodeConfigBase;
import org.hy.common.callflow.node.NodeParam;
import org.hy.common.callflow.node.ZipConfig;
import org.hy.common.xml.log.Logger;

import jnr.ffi.LibraryLoader;





/**
 * 原生元素：调用C、C++、C#生成的DLL动态库(Linux为*.so) 
 * 
 * @author      ZhengWei(HY)
 * @createDate  2025-12-02
 * @version     v1.0
 */
public class NativeConfig extends NodeConfig implements NodeConfigBase
{
    
    private static final Logger              $Logger     = new Logger(NativeConfig.class ,true);
    
    /** 单例加载DLL动态库(Linux为*.so) 。Map.key为动态库的全路径，Map.value为加载成功后的对象 */
    private static final Map<String ,Object> $LoadedLibs = new HashMap<String ,Object>();
    
    
    
    /** 执行对象的动态库文件的路径。可为空，表示已配置在运行时环境中了 */
    private String callLibrary;
    
    /** 执行对象的动态库映射的Java接口类的名称。可以是数值、上下文变量、XID标识 */
    private String callClass;
    
    
    
    public NativeConfig()
    {
        this(0L ,0L);
    }
    
    
    
    public NativeConfig(long i_RequestTotal ,long i_SuccessTotal)
    {
        super(i_RequestTotal ,i_SuccessTotal);
    }
    
    
    
    /**
     * 静态检查
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-02
     * @version     v1.0
     *
     * @param io_Result     表示检测结果
     * @return
     */
    public boolean check(Return<Object> io_Result)
    {
        // 它不能执行父类的静态检查，因为此时它的执行方法还没有确认，执行方法是在运行时确定的。
        /*
        if ( !super.check(io_Result) )
        {
            return false;
        }
        */
        
        // 执行对象不能为空
        if ( Help.isNull(this.getCallXID()) )
        {
            io_Result.set(false).setParamStr("CFlowCheck：" + this.getClass().getSimpleName() + "[" + Help.NVL(this.getXid()) + "].callXID is null.");
            return false;
        }
        
        if ( !Help.isNull(this.getCallParams()) )
        {
            int x = 0;
            for (NodeParam v_NodeParam : this.getCallParams())
            {
                x++;
                
                if ( v_NodeParam.getValue() == null && v_NodeParam.getValueDefault() == null )
                {
                    // 方法参数及默认值均会空时异常
                    io_Result.set(false).setParamStr("CFlowCheck：" + this.getClass().getSimpleName() + "[" + Help.NVL(this.getXid()) + "].callParams[" + x + "] value and valueDefault is null.");
                    return false;
                }
                
                if ( !Help.isNull(v_NodeParam.getValue()) )
                {
                    if ( !ValueHelp.isRefID(v_NodeParam.getValue()) )
                    {
                        if ( Help.isNull(v_NodeParam.getValueClass()) )
                        {
                            // 方法参数为数值类型时，参数类型应不会空
                            io_Result.set(false).setParamStr("CFlowCheck：" + this.getClass().getSimpleName() + "[" + Help.NVL(this.getXid()) + "].callParams[" + x + "] value is Normal type ,but valueClass is null.");
                            return false;
                        }
                    }
                }
                
                if ( !Help.isNull(v_NodeParam.getValueDefault()) )
                {
                    if ( !ValueHelp.isRefID(v_NodeParam.getValueDefault()) )
                    {
                        if ( Help.isNull(v_NodeParam.getValueClass()) )
                        {
                            // 方法参数的默认值为数值类型时，参数类型应不会空
                            io_Result.set(false).setParamStr("CFlowCheck：" + this.getClass().getSimpleName() + "[" + Help.NVL(this.getXid()) + "].callParams[" + x + "] valueDefault is Normal type ,but valueClass is null.");
                            return false;
                        }
                    }
                }
            }
        }
        
        return true;
    }
    
    
    
    /**
     * 运行时中获取模拟数据。
     * 
     * 建议：子类重写此方法
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-11-07
     * @version     v1.0
     *
     * @param io_Context   上下文类型的变量信息
     * @param i_BeginTime  编排元素的开始时间
     * @param io_Result    编排元素的执行结果
     * @return             表示是否有模拟数据
     */
    public boolean mock(Map<String ,Object> io_Context ,long i_BeginTime ,ExecuteResult io_Result) 
    {
        // TODO 返回类型有待商议
        return super.mock(io_Context ,i_BeginTime ,io_Result ,null ,HashMap.class.getName());
    }
    
    
    
    /**
     * 当用户没有设置XID时，可使用此方法生成
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-02
     * @version     v1.0
     *
     * @return
     */
    public String makeXID()
    {
        return "XNative_" + StringHelp.getUUID9n();
    }
    
    
    
    /**
     * 获取：执行对象的动态库文件的路径。可为空，表示已配置在运行时环境中了
     */
    public String getCallLibrary()
    {
        return callLibrary;
    }


    
    /**
     * 设置：执行对象的动态库文件的路径。可为空，表示已配置在运行时环境中了
     * 
     * @param i_CallLibrary 执行对象的动态库文件的路径。可为空，表示已配置在运行时环境中了
     */
    public void setCallLibrary(String i_CallLibrary)
    {
        this.callLibrary = i_CallLibrary;
        this.isInit      = false;
        this.reset(this.getRequestTotal() ,this.getSuccessTotal());
        this.keyChange();
    }



    /**
     * 获取：执行对象的动态库映射的Java接口类的名称。可以是数值、上下文变量、XID标识
     */
    public String getCallClass()
    {
        return callClass;
    }


    
    /**
     * 设置：执行对象的动态库映射的Java接口类的名称。可以是数值、上下文变量、XID标识
     * 
     * @param i_CallClass 执行对象的动态库映射的Java接口类的名称。可以是数值、上下文变量、XID标识
     */
    public void setCallClass(String i_CallClass)
    {
        this.callClass = i_CallClass;
        this.isInit    = false;
        this.reset(this.getRequestTotal() ,this.getSuccessTotal());
        this.keyChange();
    }
    
    
    
    /**
     * 设置XJava池中对象的ID标识。此方法不用用户调用设置值，是自动的。
     * 
     * 自己反射调用自己的实例中的方法
     * 
     * @param i_XJavaID
     */
    public void setXJavaID(String i_Xid)
    {
        super.setXJavaID(i_Xid);
        this.setCallXID(this.getXid());
    }
    
    
    
    /**
     * 元素的类型
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-02
     * @version     v1.0
     *
     * @return
     */
    public String getElementType()
    {
        return ElementType.Native.getValue();
    }
    
    
    
    /**
     * 获取XML内容中的名称，如<名称>内容</名称>
     * 
     * 建议：子类重写此方法
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-02
     * @version     v1.0
     *
     * @return
     */
    public String toXmlName()
    {
        return ElementType.Native.getXmlName();
    }
    
    
    
    /**
     * 转XML时是否显示retFalseIsError属性
     * 
     * 建议：子类重写此方法
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-02
     * @version     v1.0
     *
     * @return
     */
    public boolean xmlShowRetFalseIsError()
    {
        return false;
    }
    
    
    
    /**
     * 执行方法前，对执行对象的处理
     * 
     * 建议：子类重写此方法
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-15
     * @version     v1.0
     *
     * @param io_Context        上下文类型的变量信息
     * @param io_ExecuteObject  执行对象。已用NodeConfig自己的力量生成了执行对象。
     * @return
     */
    public Object generateObject(Map<String ,Object> io_Context ,Object io_ExecuteObject)
    {
        // 其实就是返回自己。io_ExecuteObject 获取正确时，也是this自己
        return io_ExecuteObject == null ? this : io_ExecuteObject;
    }
    
    
    
    /**
     * 执行方法前，对方法入参的处理、加工、合成
     * 
     * 建议：子类重写此方法
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-09-15
     * @version     v1.0
     *
     * @param io_Context  上下文类型的变量信息
     * @param io_Params   方法执行参数。已用NodeConfig自己的力量生成了执行参数。
     * @return
     * @throws Exception 
     */
    public Object [] generateParams(Map<String ,Object> io_Context ,Object [] io_Params)
    {
        return io_Params;
    }
    
    
    
    /**
     * 单例模式加载DLL动态库(Linux为*.so)
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-02
     * @version     v1.0
     *
     * @param i_LibName  DLL动态库(Linux为*.so)的全路径
     * @return
     */
    private synchronized Object loadLibrary(String i_LibName)
    {
        Object v_Library = $LoadedLibs.get(i_LibName);
        if ( v_Library != null )
        {
            return v_Library;
        }
        
        String v_LibName = StringHelp.replaceAll(i_LibName.trim() ,"\\" ,"/");
        File   v_LibFile = new File(v_LibName);
        
        if ( !v_LibFile.exists() )
        {
            throw new RuntimeException(Help.NVL(this.getXid()) + " Library[" + i_LibName + "] is not exists");
        }
        
        try
        {
            LibraryLoader<?> v_Loader = LibraryLoader.create(Void.class);
            v_Library = v_Loader.load(v_LibName);
            $LoadedLibs.put(v_LibName ,v_Loader);
            return v_Library;
        }
        catch (Exception exce)
        {
            throw new RuntimeException(Help.NVL(this.getXid()) + " loader Library[" + i_LibName + "] error" ,exce);
        }
    }
    
    
    
    private synchronized void buildMethod()
    {
    }
    
    
    
    /**
     * 生成或写入个性化的XML内容
     * 
     * 建议：子类重写此方法
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-15
     * @version     v1.0
     *
     * @param io_Xml         XML内容的缓存区
     * @param i_Level        层级。最小下标从0开始。
     *                           0表示每行前面有0个空格；
     *                           1表示每行前面有4个空格；
     *                           2表示每行前面有8个空格；
     * @param i_Level1       单级层级的空格间隔
     * @param i_LevelN       N级层级的空格间隔
     * @param i_SuperTreeID  父级树ID
     * @param i_TreeID       当前树ID
     */
    public void toXmlContent(StringBuilder io_Xml ,int i_Level ,String i_Level1 ,String i_LevelN ,String i_SuperTreeID ,String i_TreeID)
    {
        String v_NewSpace = "\n" + i_LevelN + i_Level1;
        
        if ( !Help.isNull(this.callLibrary) )
        {
            io_Xml.append(v_NewSpace).append(IToXml.toValue("callLibrary" ,this.callLibrary));
        }
        if ( !Help.isNull(this.callClass) )
        {
            io_Xml.append(v_NewSpace).append(IToXml.toValue("callClass"   ,this.callClass));
        }
    }
    
    
    
    /**
     * 解析为实时运行时的执行表达式
     * 
     * 注：禁止在此真的执行方法
     *
     * @author      ZhengWei(HY)
     * @createDate  2025-12-15
     * @version     v1.0
     *
     * @param i_Context  上下文类型的变量信息
     * @return
     */
    public String toString(Map<String ,Object> i_Context)
    {
        StringBuilder       v_Builder = new StringBuilder();
        Map<String ,Object> v_In      = null;
        
        return v_Builder.toString();
    }
    
    
    
    /**
     * 解析为执行表达式
     *
     * @author      ZhengWei(HY)
     * @createDate  2025-12-15
     * @version     v1.0
     *
     * @return
     */
    @Override
    public String toString()
    {
        StringBuilder v_Builder = new StringBuilder();
        
        return v_Builder.toString();
    }
    
    
    
    /**
     * 仅仅创建一个新的实例，没有任何赋值
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-02
     * @version     v1.0
     *
     * @return
     */
    public Object newMy()
    {
        return new NativeConfig();
    }
    
    
    
    /**
     * 浅克隆，只克隆自己，不克隆路由。
     * 
     * 注：不克隆XID。
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-02
     * @version     v1.0
     *
     */
    public Object cloneMyOnly()
    {
        NativeConfig v_Clone = new NativeConfig();
        
        this.cloneMyOnly(v_Clone);
        // v_Clone.callXID  = this.callXID;     不能克隆callXID，因为它就是类自己的xid
        v_Clone.callMethod  = this.callMethod; 
        v_Clone.timeout     = this.timeout;
        v_Clone.callLibrary = this.callLibrary; 
        v_Clone.callClass   = this.callClass; 
        
        if ( !Help.isNull(this.callParams) )
        {
            v_Clone.callParams = new ArrayList<NodeParam>();
            for (NodeParam v_NodeParam : this.callParams)
            {
                v_Clone.callParams.add((NodeParam) v_NodeParam.cloneMyOnly());
            }
        }
        
        return v_Clone;
    }
    
    
    
    /**
     * 深度克隆编排元素
     * 
     * 建议：子类重写此方法
     * 
     * @author      ZhengWei(HY)
     * @createDate  2025-12-15
     * @version     v1.0
     *
     * @param io_Clone        克隆的复制品对象
     * @param i_ReplaceXID    要被替换掉的XID中的关键字（可为空）
     * @param i_ReplaceByXID  新的XID内容，替换为的内容（可为空）
     * @param i_AppendXID     替换后，在XID尾追加的内容（可为空）
     * @param io_XIDObjects   已实例化的XID对象。Map.key为XID值
     * @return
     */
    public void clone(Object io_Clone ,String i_ReplaceXID ,String i_ReplaceByXID ,String i_AppendXID ,Map<String ,ExecuteElement> io_XIDObjects)
    {
        if ( Help.isNull(this.xid) )
        {
            throw new NullPointerException("Clone NativeConfig xid is null.");
        }
        
        NativeConfig v_Clone = (NativeConfig) io_Clone;
        ((ExecuteElement) this).clone(v_Clone ,i_ReplaceXID ,i_ReplaceByXID ,i_AppendXID ,io_XIDObjects);
        
        // v_Clone.callXID  = this.callXID;     不能克隆callXID，因为它就是类自己的xid
        v_Clone.callMethod  = this.callMethod; 
        v_Clone.timeout     = this.timeout;
        v_Clone.callLibrary = this.callLibrary; 
        v_Clone.callClass   = this.callClass; 
        
        if ( !Help.isNull(this.callParams) )
        {
            v_Clone.callParams = new ArrayList<NodeParam>();
            for (NodeParam v_NodeParam : this.callParams)
            {
                v_Clone.callParams.add((NodeParam) v_NodeParam.cloneMyOnly());
            }
        }
    }
    
    
    
    /**
     * 深度克隆编排元素
     * 
     * 建议：子类重写此方法
     *
     * @author      ZhengWei(HY)
     * @createDate  2025-12-15
     * @version     v1.0
     *
     * @return
     * @throws CloneNotSupportedException
     *
     * @see java.lang.Object#clone()
     */
    @Override
    public Object clone() throws CloneNotSupportedException
    {
        if ( Help.isNull(this.xid) )
        {
            throw new NullPointerException("Clone NativeConfig xid is null.");
        }
        
        Map<String ,ExecuteElement> v_XIDObjects = new HashMap<String ,ExecuteElement>();
        Return<String>              v_Version    = parserXIDVersion(this.xid);
        NativeConfig                v_Clone      = new NativeConfig();
        
        if ( v_Version.booleanValue() )
        {
            this.clone(v_Clone ,v_Version.getParamStr() ,XIDVersion + (v_Version.getParamInt() + 1) ,""         ,v_XIDObjects);
        }
        else
        {
            this.clone(v_Clone ,""                      ,""                                         ,XIDVersion ,v_XIDObjects);
        }
        
        v_XIDObjects.clear();
        v_XIDObjects = null;
        return v_Clone;
    }
    
}
