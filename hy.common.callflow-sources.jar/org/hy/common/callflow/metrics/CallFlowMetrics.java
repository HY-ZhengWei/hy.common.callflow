package org.hy.common.callflow.metrics;





/**
 * 编排实例相关指标的统计（每分钟级的量）
 *
 * @author      ZhengWei(HY)
 * @createDate  2026-09-20
 * @version     v1.0
 */
public class CallFlowMetrics
{
    
    /** 编排数量 */
    private int callflowCount;
    
    /** 编排元素节点数量 */
    private int elementCount;
    
    /** 编排物联节点数量 */
    private int elementIoTCount;
    
    /** 编排接口节点数量 */
    private int elementApiCount;
    
    /** 编排定时节点数量 */
    private int elementJobCount;
    
    /** 编排实例数量 */
    private int instanceCount;
    
    /** 编排实例执行成功数量 */
    private int instanceSucceed;
    
    /** 编排实例执行异常数量 */
    private int instanceError;
    
    /** 编排实例执行中的数量 */
    private int instanceActive;
    
    /** 编排实例执行成功的用时（单位：毫秒） */
    private int instanceSucceedTime;
    
    
    
    /**
     * 获取：编排数量
     */
    public int getCallflowCount()
    {
        return callflowCount;
    }

    
    /**
     * 设置：编排数量
     * 
     * @param i_CallflowCount 编排数量
     */
    public void setCallflowCount(int i_CallflowCount)
    {
        this.callflowCount = i_CallflowCount;
    }

    
    /**
     * 获取：编排元素节点数量
     */
    public int getElementCount()
    {
        return elementCount;
    }

    
    /**
     * 设置：编排元素节点数量
     * 
     * @param i_ElementCount 编排元素节点数量
     */
    public void setElementCount(int i_ElementCount)
    {
        this.elementCount = i_ElementCount;
    }

    
    /**
     * 获取：编排物联节点数量
     */
    public int getElementIoTCount()
    {
        return elementIoTCount;
    }

    
    /**
     * 设置：编排物联节点数量
     * 
     * @param i_ElementIoTCount 编排物联节点数量
     */
    public void setElementIoTCount(int i_ElementIoTCount)
    {
        this.elementIoTCount = i_ElementIoTCount;
    }

    
    /**
     * 获取：编排接口节点数量
     */
    public int getElementApiCount()
    {
        return elementApiCount;
    }

    
    /**
     * 设置：编排接口节点数量
     * 
     * @param i_ElementApiCount 编排接口节点数量
     */
    public void setElementApiCount(int i_ElementApiCount)
    {
        this.elementApiCount = i_ElementApiCount;
    }

    
    /**
     * 获取：编排定时节点数量
     */
    public int getElementJobCount()
    {
        return elementJobCount;
    }

    
    /**
     * 设置：编排定时节点数量
     * 
     * @param i_ElementJobCount 编排定时节点数量
     */
    public void setElementJobCount(int i_ElementJobCount)
    {
        this.elementJobCount = i_ElementJobCount;
    }

    
    /**
     * 获取：编排实例数量
     */
    public int getInstanceCount()
    {
        return instanceCount;
    }

    
    /**
     * 设置：编排实例数量
     * 
     * @param i_InstanceCount 编排实例数量
     */
    public void setInstanceCount(int i_InstanceCount)
    {
        this.instanceCount = i_InstanceCount;
    }

    
    /**
     * 获取：编排实例执行成功数量
     */
    public int getInstanceSucceed()
    {
        return instanceSucceed;
    }

    
    /**
     * 设置：编排实例执行成功数量
     * 
     * @param i_InstanceSucceed 编排实例执行成功数量
     */
    public void setInstanceSucceed(int i_InstanceSucceed)
    {
        this.instanceSucceed = i_InstanceSucceed;
    }

    
    /**
     * 获取：编排实例执行异常数量
     */
    public int getInstanceError()
    {
        return instanceError;
    }

    
    /**
     * 设置：编排实例执行异常数量
     * 
     * @param i_InstanceError 编排实例执行异常数量
     */
    public void setInstanceError(int i_InstanceError)
    {
        this.instanceError = i_InstanceError;
    }

    
    /**
     * 获取：编排实例执行中的数量
     */
    public int getInstanceActive()
    {
        return instanceActive;
    }

    
    /**
     * 设置：编排实例执行中的数量
     * 
     * @param i_InstanceActive 编排实例执行中的数量
     */
    public void setInstanceActive(int i_InstanceActive)
    {
        this.instanceActive = i_InstanceActive;
    }

    
    /**
     * 获取：编排实例执行成功的用时（单位：毫秒）
     */
    public int getInstanceSucceedTime()
    {
        return instanceSucceedTime;
    }

    
    /**
     * 设置：编排实例执行成功的用时（单位：毫秒）
     * 
     * @param i_InstanceSucceedTime 编排实例执行成功的用时（单位：毫秒）
     */
    public void setInstanceSucceedTime(int i_InstanceSucceedTime)
    {
        this.instanceSucceedTime = i_InstanceSucceedTime;
    }
    
}
