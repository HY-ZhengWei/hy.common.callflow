package org.hy.common.callflow.metrics;


public class CallFlowMetricsJob
{
}
